package com.example.devapp;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.example.devapp.controller.OperatorController;
import com.example.devapp.pojo.InputFix;
import com.example.devapp.process.OperatorProcess;
import com.example.devapp.repository.implementation.OperatorRepositoryImplementation;

//@SpringBootTest
class DevappApplicationTests {

	@Test
	void getPostfix() {
		OperatorRepositoryImplementation repository = new OperatorRepositoryImplementation(); 
		OperatorProcess operProcess = new OperatorProcess(repository);
		OperatorController operController = new OperatorController(operProcess);
		InputFix infix = new InputFix();
		infix.setExp("1+2.5/3*4");
		assertNotNull(operController.getResult(infix ));
	}
}
