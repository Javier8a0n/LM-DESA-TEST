package com.example.devapp.repository.implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.devapp.pojo.OperatorPrecedence;
import com.example.devapp.repository.OperatorRepository;

//@Service
public class OperatorRepositoryImplementation implements OperatorRepository {

	@Override
	public List<OperatorPrecedence> getOperators() {
		//agregar conexion a la base de datos y quitar objeto de prueba
		List<OperatorPrecedence> lret = new ArrayList<>();
		OperatorPrecedence ret = new OperatorPrecedence();
		ret.setOperator("^"); ret.setPrecedence(4);
		lret.add(ret);
		
		ret = new OperatorPrecedence();
		ret.setOperator("*"); ret.setPrecedence(3);
		lret.add(ret);
		
		ret = new OperatorPrecedence();
		ret.setOperator("/"); ret.setPrecedence(3);
		lret.add(ret);
		
		ret = new OperatorPrecedence();
		ret.setOperator("+"); ret.setPrecedence(2);
		lret.add(ret);
		
		ret = new OperatorPrecedence();
		ret.setOperator("-"); ret.setPrecedence(2);
		lret.add(ret);

		return lret;
	}

}
