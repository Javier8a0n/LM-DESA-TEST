package com.example.devapp.repository;

import java.util.List;

import com.example.devapp.pojo.OperatorPrecedence;

public interface OperatorRepository {
	public List<OperatorPrecedence> getOperators();
}
