package com.example.devapp.pojo;

import java.util.Map;

public class OutputFix {
	private String code;
	private Map<String, String> response;

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Map<String, String> getResponse() {
		return response;
	}
	public void setResponse(Map<String, String> response) {
		this.response = response;
	}
}