package com.example.devapp.pojo;

public class InputFix {
	private String exp;

	public String getExp() {
		return exp;
	}

	public void setExp(String exp) {
		this.exp = exp;
	}
}