package com.example.devapp.pojo;

public class OperatorPrecedence {
	private String operator;
	private int precedence;
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public int getPrecedence() {
		return precedence;
	}
	public void setPrecedence(int precedence) {
		this.precedence = precedence;
	}	
}
