package com.example.devapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.devapp.pojo.InputFix;
import com.example.devapp.pojo.OutputFix;
import com.example.devapp.process.OperatorProcess;

//@Controller
public class OperatorController {
	private OperatorProcess operProcess;

	public OperatorController(OperatorProcess operProcess) {
		this.operProcess = operProcess;
	}
	
//	@RequestMapping("/evaluate")
	public OutputFix getResult(InputFix infix){
		return operProcess.process(infix);
	}
}
