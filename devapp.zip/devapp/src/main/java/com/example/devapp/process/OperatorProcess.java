package com.example.devapp.process;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import com.example.devapp.pojo.InputFix;
import com.example.devapp.pojo.OperatorPrecedence;
import com.example.devapp.pojo.OutputFix;
import com.example.devapp.repository.OperatorRepository;

//@Service
public class OperatorProcess {
	private OperatorRepository repository;

	public OperatorProcess(OperatorRepository repository) {
		this.repository = repository;
	}

	public OutputFix process(InputFix infix) {
		OutputFix out = new OutputFix();
		try {
		out.setCode("200");
		
		//agregar validacion si trae letras el texto enviado
		
		Map<String, String> result = new HashMap<String, String>();
		result.put("infix", infix.getExp());
		
		List<OperatorPrecedence> lsign = repository.getOperators();
		
		String sign = "";
		Map<String, Integer> signPrec = new HashMap<>();
		for (OperatorPrecedence operatorPrecedence : lsign) {
			sign+=operatorPrecedence.getOperator();
			signPrec.put(operatorPrecedence.getOperator(), operatorPrecedence.getPrecedence());
		}
		
		String postFix = getPostFix(infix.getExp(), sign, signPrec);
		result.put("postfix", postFix);
		
		String[] numbers = infix.getExp().split("[\\"+sign+"]");
		
		//funciona para calcular resultado
		
		out.setResponse(result);
		
		}catch (Exception e) {
			e.printStackTrace();
			//Agregar estructura de error - objeto ya definido
		}
		return out;
	}

	private String getPostFix(String exp, String sign, Map<String, Integer> signPrec) {
		List<String> operating = new ArrayList<String>();
		Map<String, Integer> operator = new HashMap<>(); 
		
		char[] expAr = exp.toCharArray();
		for (int i = 0; i < expAr.length; i++) {
			String c = String.valueOf(expAr[i]);
			if(sign.contains(c)) {
				validateOperator(c, operator, operating, signPrec);
			} else {
				operating.add(c);
			}
		}
		
		return getString(operator, operating);
	}

	private void validateOperator(String c, Map<String, Integer> operator, List<String> operating, Map<String, Integer> signPrec) {
		int pre = signPrec.get(c);
		
		if(operator.containsValue(pre)) {		
			List<String> operRemove = new ArrayList<String>();
			for (Entry<String, Integer> op : operator.entrySet()) {
				if(op.getValue() == pre) {
					operating.add(op.getKey());
					operRemove.add(op.getKey());
				}
			}
			
			operRemove.forEach(x -> operator.remove(x));
			operator.put(c, signPrec.get(c));
		}else {
			operator.put(c, signPrec.get(c));
		}
	}

	private String getString(Map<String, Integer> operator, List<String> operating) {

		StringBuilder res = new StringBuilder();
		
		for (int i = 0; i < operating.size(); i++) {
			res.append(operating.get(i));
		}
		
		for ( String key : operator.keySet()) {
			res.append(key);
		}
		
		System.out.println(res.toString());
		
		return res.toString();
	}
}
