package main

import "JavierOchoaPracticalTest/ConversionFachada"

func main() {
	fachada := ConversionFachada.NewConvFachada()
	fachada.Encode("Kennia")
}
