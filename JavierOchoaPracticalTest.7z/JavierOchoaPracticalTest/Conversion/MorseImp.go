package Conversion

import (
	"encoding/json"
	"fmt"
	"strings"
)

type MorseText struct {
}

func NewEncodeMorse() *MorseText {
	return &MorseText{}
}

func (t MorseText) Encode(text string)  {
	var MorseMap map[string]string
	morse := `{"A": ".- ","B": "-... ","C": "-.-. ","D": "-.. ","E": ". ","F": "..-. ","G": "--. ","H": ".... ","I": ".. ","J": ".--- ","K": "-.- ","L": ".-.. ", "M": "-- ","N": "-. ","O": "--- ","P": ".--. ","Q": "--.- ","R": ".-. ","S": "... ","T": "- ","U ": "..- ","V": "...- ","W": ".-- ","X": "-..- ","Y": "-.-- ","Z": "--.. ", " ":"   " }`
	json.Unmarshal([]byte(morse), &MorseMap)

	txAux := strings.ToUpper(text)
	var txConvertido string
	for _, lt := range txAux {
		txConvertido += MorseMap[string(lt)]
	}
	fmt.Println(txConvertido)
}