package Conversion

import "fmt"

type MulcielagoText struct {
}

func NewEncodeMurcielago() *MulcielagoText {
	return &MulcielagoText{}
}

func (t MulcielagoText) Encode(text string)  {

	fmt.Println("Murcielago")
}