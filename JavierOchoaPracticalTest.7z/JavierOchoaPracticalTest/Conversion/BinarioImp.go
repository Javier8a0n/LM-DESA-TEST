package Conversion

import (
	"fmt"
)

type BinarioText struct {
}

func NewEncodeBinario() *BinarioText {
	return &BinarioText{}
}

func (t BinarioText) Encode(text string)  {
	var txConvertido string
	for _, c := range text {
		txConvertido += fmt.Sprintf("%.8b",c)
		txConvertido += " "
	}
	fmt.Println(txConvertido)
}