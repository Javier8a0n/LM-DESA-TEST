package Conversion

type Encoder interface {
	Encode(text string)
}
