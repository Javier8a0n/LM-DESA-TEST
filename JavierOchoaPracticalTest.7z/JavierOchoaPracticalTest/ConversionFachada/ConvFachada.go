package ConversionFachada

import "JavierOchoaPracticalTest/Conversion"

type ConvFachada struct {
	morse *Conversion.MorseText
	binario *Conversion.BinarioText
	murcielago *Conversion.MulcielagoText
}

func NewConvFachada() *ConvFachada {
	return &ConvFachada{
		morse: Conversion.NewEncodeMorse(),
		binario: Conversion.NewEncodeBinario(),
		murcielago: Conversion.NewEncodeMurcielago(),
	}
}

func (r ConvFachada) Encode(text string) {
	r.morse.Encode(text)
	r.binario.Encode(text)
	r.murcielago.Encode(text)
}